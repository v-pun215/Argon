print("Installing...")
import os
os.system("pip install -r requirements.txt")
print("Installed!")
os.system("python main.py")